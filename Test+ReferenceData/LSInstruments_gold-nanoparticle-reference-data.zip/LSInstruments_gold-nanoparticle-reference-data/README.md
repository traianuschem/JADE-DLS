# LS Instruments cross-validation data of the gold-nanoparticle reference samples

Data: Florian Trummer (ORCID: https://orcid.org/0000-0002-3831-3825), TU Freiberg. Licensed under **CC BY-SA 4.0**
(see [LICENSE](LICENSE)). The files are the unmodified exports of the LS Spectrometer software; the original note of the
data provider is kept as `readme_original_Trummer.txt` (German).

## Measurement

Same samples as the ALV data of the (J)ADE-DLS reference set (`ALV_gold-nanoparticle-reference-data.zip`), measured on an
LS Spectrometer (LS Instruments, Fribourg, Switzerland): wavelength 561 nm, 2D pseudo cross-correlation, water as
solvent, about 298 K, 12 s per measurement, scattering angles 30°–150° in 10° steps with several repetitions per angle.
Angles above 130° are not reliable because of reflections in the instrument; the paper uses 40°–130°.

| Folder | Paper label |
|---|---|
| `Au1` | Au1 (30 nm) |
| `Au2` | Au2 (100 nm) |
| `Au3` | Au3 (200 nm) |
| `Au1_plus_Au2` | Au1+Au2 (binary mixture) |
| `Au1plusAu3` | Au1+Au3 (binary mixture) |
| `Au2_plus_Au3` | Au2+Au3 (binary mixture) |
| `Au1_plus_Au2_plus_Au3` | Au1+Au2+Au3 (ternary mixture) |

The folder names are those of the provider and are intentionally not renamed.

## Structure

`<sample>/Measurement <n>/Repetition<m>/` (one measurement per folder; the number of repetitions per angle varies):

* `Summary.csv` — metadata (angle, temperature, solvent, duration, mean count rates A/B, laser intensity, instrument
  cumulant result);
* `Correlation Function.csv`, `Count Trace.csv` — raw correlation function and count-rate trace;
* `Cumulants Results.csv` — cumulant results of the instrument software (cumulant orders 1–3);
* `CORENN Intensity|Number|Volume|Gamma Results.csv` — CORENN distributions of the instrument software.

`CSV format version.txt` in each sample folder gives the export format version. The (J)ADE-DLS parser for this format is
`ade_dls/core/parsers/ls_instruments_parser.py`.

## Notes on the CORENN results

* CORENN evaluates each correlation function separately (single angle).
* **For the mixtures, CORENN was manually optimised only at 50°, 90° and 130°.** At all other angles the results were
  obtained with the default parameters of the software and should not be used for quantitative comparisons.
* CORENN is sensitive to the starting conditions and tends to produce virtual peaks, especially at small radii; these
  have to be discarded.
