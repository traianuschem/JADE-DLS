2D Pseudo cross correlation gemessen auf LS Spectrometer 1 mit lambda =561nm.
Winkel >130° sind nicht zuverlässig wegen Refelxen im Gerät.
Daten sind vorbereinigt (Cumulant)
Für CORENN wurden NUR DIE DATENSÄTZE DER MISCHUNGEN UND NUR DIE WINKEL 50°, 90° &130° HÄNDISCH NACHOPTIMIERT.

CORENN ist sensitiv auf Startbedingungen und baut vor allem bei kleinen Radien gerne virtuelle Peaks ein. Diese sind zu verwerfen.